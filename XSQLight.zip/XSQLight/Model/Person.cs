﻿using System;
using SQLite;
using System.Collections.Generic;
using System.Text;

namespace XSQLight
{
  public  class Person
    {
        [PrimaryKey, AutoIncrement]
        public int PersonID { get; set; }
        public string Name { get; set; }

        //Check this

        public byte[] itemData { get; set; }
    }
}
